-- 哔哩哔哩 Gateway 入口
-- 宿主调用 call(operation, args)，args 里始终带 platform 字段。

local account = require("bb.account")
local catalog = require("bb.catalog")
local discover = require("bb.discover")
local transport = require("bb.transport")
local util = require("bb.util")

local plugin = {}

local providers = {
  {
    id = "bilibili",
    name = "哔哩哔哩",
    auth = { "qr", "cookie" },
    capabilities = {
      "search",
      "playlists",
      "favorites",
      "lyrics",
      "comments",
      "homeFeed",
      "charts",
      "radio",
      "recommendations",
    },
    loginHint = "用哔哩哔哩 App 扫码，或粘贴浏览器里的 Cookie",
    cookieHint = "从已登录网页版复制整段 Cookie（需包含 SESSDATA 与 bili_jct）",
  },
}

--- 收藏 / 取消收藏：B 站用「收藏夹」承载，收藏进默认收藏夹。
local function setFavorite(args)
  if not transport.loggedIn() then
    return { error = { code = 41, httpStatus = 401 } }
  end
  local id = util.str(args and args.id)
  local favorite = args and args.favorite == true
  if id == "" then return { error = { code = 400 } } end

  -- 需要 aid 而不是 bvid
  local params = {}
  if id:sub(1, 2) == "av" then
    params.aid = id:sub(3)
  else
    params.bvid = id
  end
  local view = transport.request({
    path = "/x/web-interface/view",
    params = params,
    signed = false,
  })
  if type(view) ~= "table" then return { error = { code = 70 } } end
  local aid = util.str(view.aid)
  if aid == "" then return { error = { code = 70 } } end

  -- 找默认收藏夹
  local nav = transport.request({
    path = "/x/web-interface/nav",
    params = {},
    signed = false,
  })
  local mid = type(nav) == "table" and util.str(nav.mid) or ""
  if mid == "" then return { error = { code = 41, httpStatus = 401 } } end

  local folders = transport.request({
    path = "/x/v3/fav/folder/created/list-all",
    params = { up_mid = mid },
    signed = false,
  })
  local folderId = nil
  if type(folders) == "table" and type(folders.list) == "table" and folders.list[1] then
    folderId = util.str(folders.list[1].id)
  end
  if not folderId then return { error = { code = 70 } } end

  local form = {
    rid = aid,
    type = 2,
    csrf = transport.csrf(),
  }
  if favorite then
    form.add_media_ids = folderId
  else
    form.del_media_ids = folderId
  end

  local result = transport.request({
    path = "/x/v3/fav/resource/deal",
    params = {},
    method = "POST",
    form = form,
    signed = false,
  })
  if result == nil then return { error = { code = 70 } } end
  return true
end

local handlers = {
  -- 元数据
  describe = function()
    return { providers = providers }
  end,

  -- 账号
  session = function() return account.session() end,
  logout = function() return account.logout() end,
  loginCookie = function(args) return account.loginCookie(args) end,
  qrKey = function() return account.qrKey() end,
  qrUrl = function(args) return account.qrUrl(args) end,
  qrCheck = function(args) return account.qrCheck(args) end,
  exportCookie = function() return account.exportCookie() end,

  -- 目录
  search = function(args) return catalog.search(args) end,
  song = function(args) return catalog.song(args) end,
  stream = function(args) return catalog.stream(args) end,
  lyrics = function(args) return catalog.lyrics(args) end,
  artist = function(args) return catalog.artist(args) end,
  artistSongs = function(args) return catalog.artistSongs(args) end,
  artistAlbums = function(args) return catalog.artistAlbums(args) end,
  playlist = function(args) return catalog.playlist(args) end,
  playlistSongs = function(args) return catalog.playlistSongs(args) end,
  comments = function(args) return catalog.comments(args) end,
  setCommentLiked = function(args) return catalog.setCommentLiked(args) end,

  -- 发现
  homeFeed = function() return discover.homeFeed() end,
  charts = function() return discover.charts() end,
  playlists = function(args) return discover.playlists(args) end,
  favorites = function(args) return discover.favorites(args) end,
  recommendations = function(args) return discover.recommendations(args) end,
  radio = function(args) return discover.radio(args) end,
  setFavorite = function(args) return setFavorite(args) end,
}

function plugin.call(operation, args)
  args = args or {}
  local handler = handlers[operation]
  if handler == nil then
    -- 未实现的操作返回 nil，宿主会当成空结果而不是崩溃
    return nil
  end
  local ok, result = pcall(handler, args)
  if not ok then
    return { error = { code = 500 } }
  end
  return result
end

return plugin
