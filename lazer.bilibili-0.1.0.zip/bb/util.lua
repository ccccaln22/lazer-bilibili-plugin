-- 通用小工具：编码、哈希、时间、文本清洗。
-- 不依赖任何宿主以外的模块，方便单测。

local util = {}

--- 把任意值安全地转成字符串（nil 变空串）。
function util.str(value)
  if value == nil then return "" end
  if type(value) == "string" then return value end
  if type(value) == "number" then
    -- Lua 5.3 里整数会带 ".0"，这里统一去掉无意义的小数尾巴
    if value == math.floor(value) then
      return string.format("%.0f", value)
    end
    return tostring(value)
  end
  if type(value) == "boolean" then
    return value and "true" or "false"
  end
  return tostring(value)
end

--- 字符串长度。
-- 必须用这个代替 #str：Lazer 内置的 Lua VM（lua_dardo_plus）里 `len`
-- 指令对字符串压入长度后没有提前返回，随后会走进 `val is LuaTable`
-- 分支抛异常。宿主换用原生 Lua 也没问题，两种环境都安全。
function util.slen(text)
  local value = text
  if type(value) ~= "string" then value = util.str(value) end
  return string.len(value)
end

--- 取整数，失败回退默认值。
function util.int(value, fallback)
  local n = tonumber(value)
  if n == nil then return fallback or 0 end
  return math.floor(n)
end

--- 整数形式的毫秒时间戳。
function util.nowMs()
  return math.floor(host.now())
end

--- 秒级时间戳。
function util.nowSec()
  return math.floor(host.now() / 1000)
end

--- B 站 WBI 要求的百分号编码。
-- 先剔除 !'()* 五个字符（与官方签名脚本一致），再做 URL 编码。
-- 空格必须保持 %20，不能写成 +，否则签名和实际请求会算出不同摘要。
function util.encode(value)
  local text = util.str(value)
  -- 手工剔除 B 站签名要求忽略的五个字符，不用 gsub
  local kept = {}
  for index = 1, util.slen(text) do
    local char = string.sub(text, index, index)
    if char ~= "!" and char ~= "'" and char ~= "(" and char ~= ")" and char ~= "*" then
      kept[#kept + 1] = char
    end
  end
  return host.url_encode(table.concat(kept))
end

--- 把 key=value 表拼成查询串（按 key 排序，签名与请求共用）。
function util.query(fields)
  local keys = {}
  for key in pairs(fields) do
    keys[#keys + 1] = tostring(key)
  end
  table.sort(keys)
  local parts = {}
  for _, key in ipairs(keys) do
    parts[#parts + 1] = util.encode(key) .. "=" .. util.encode(fields[key])
  end
  return table.concat(parts, "&")
end

--- md5 小写十六进制。
function util.md5(text)
  return host.crypto({ operation = "md5", text = util.str(text) })
end

-- ======================================================================
-- 纯字符串工具（不依赖 Lua 模式匹配）
--
-- Lazer 内置的 lua_dardo_plus 里 string.gsub 完全失效（原样返回、
-- 计数恒为 0），string.gmatch 会抛 RangeError，带 pattern 的 find
-- 返回 nil。所以这里全部用 string.sub / string.find(plain) / string.byte
-- 手写，宿主换回原生 Lua 时结果也一样。
-- ======================================================================

--- 把一段文本里所有 old 换成 new（纯字面量，非模式）。
function util.replace(text, old, new)
  local src = util.str(text)
  local needle = util.str(old)
  local replacement = util.str(new)
  if needle == "" then return src end
  local out = {}
  local pos = 1
  local length = util.slen(src)
  local step = util.slen(needle)
  while true do
    local found = string.find(src, needle, pos, true)
    if not found then
      out[#out + 1] = string.sub(src, pos)
      break
    end
    out[#out + 1] = string.sub(src, pos, found - 1)
    out[#out + 1] = replacement
    pos = found + step
    if pos > length + 1 then break end
  end
  return table.concat(out)
end

--- 按分隔符切分，保留空段。separator 必须是单个字符。
function util.split(text, separator)
  local src = util.str(text)
  local sep = util.str(separator)
  local out = {}
  if sep == "" then
    out[1] = src
    return out
  end
  local start = 1
  while true do
    local found = string.find(src, sep, start, true)
    if not found then
      out[#out + 1] = string.sub(src, start)
      break
    end
    out[#out + 1] = string.sub(src, start, found - 1)
    start = found + 1
  end
  return out
end

--- 去掉字符串首尾的空白与指定字符。
function util.trim(text)
  local src = util.str(text)
  local first, last = 1, util.slen(src)
  while first <= last do
    local byte = string.byte(src, first)
    if byte == 32 or byte == 9 or byte == 10 or byte == 13 then
      first = first + 1
    else
      break
    end
  end
  while last >= first do
    local byte = string.byte(src, last)
    if byte == 32 or byte == 9 or byte == 10 or byte == 13 then
      last = last - 1
    else
      break
    end
  end
  if first > last then return "" end
  return string.sub(src, first, last)
end

--- 是否以 prefix 开头。
function util.startsWith(text, prefix)
  local src = util.str(text)
  local head = util.str(prefix)
  if head == "" then return true end
  if util.slen(src) < util.slen(head) then return false end
  return string.sub(src, 1, util.slen(head)) == head
end

--- 是否以 suffix 结尾。
function util.endsWith(text, suffix)
  local src = util.str(text)
  local tail = util.str(suffix)
  local srcLen = util.slen(src)
  local tailLen = util.slen(tail)
  if tailLen == 0 then return true end
  if srcLen < tailLen then return false end
  return string.sub(src, srcLen - tailLen + 1) == tail
end

--- 字面量包含判断。
function util.contains(text, needle)
  return string.find(util.str(text), util.str(needle), 1, true) ~= nil
end

--- 取最后一个分隔符之后的部分（等价于 url:match("([^/]+)$")）。
function util.afterLast(text, separator)
  local src = util.str(text)
  local sep = util.str(separator)
  if sep == "" then return src end
  local last = nil
  local start = 1
  while true do
    local found = string.find(src, sep, start, true)
    if not found then break end
    last = found
    start = found + util.slen(sep)
  end
  if last == nil then return src end
  return string.sub(src, last + util.slen(sep))
end

--- 取第一个分隔符之前的部分。
function util.beforeFirst(text, separator)
  local src = util.str(text)
  local found = string.find(src, util.str(separator), 1, true)
  if not found then return src end
  return string.sub(src, 1, found - 1)
end

--- 只保留数字字符（用于从 "BV1xx" / "12:34" 里抽数字）。
function util.digitsOnly(text)
  local src = util.str(text)
  local out = {}
  for index = 1, util.slen(src) do
    local byte = string.byte(src, index)
    if byte >= 48 and byte <= 57 then
      out[#out + 1] = string.char(byte)
    end
  end
  return table.concat(out)
end

--- 是否是纯数字
function util.isDigits(text)
  local src = util.str(text)
  if src == "" then return false end
  return util.slen(util.digitsOnly(src)) == util.slen(src)
end

--- 把 HTML 实体还原
function util.unescape(text)
  local value = util.str(text)
  value = util.replace(value, "&amp;", "&")
  value = util.replace(value, "&lt;", "<")
  value = util.replace(value, "&gt;", ">")
  value = util.replace(value, "&quot;", '"')
  value = util.replace(value, "&#39;", "'")
  value = util.replace(value, "&apos;", "'")
  value = util.replace(value, "&nbsp;", " ")
  return value
end

--- 去掉 <em class="keyword"> 这类标签（逐字符扫描，不用模式）。
function util.stripTags(value)
  local src = util.str(value)
  if not util.contains(src, "<") then return util.unescape(src) end
  local out = {}
  local inTag = false
  for index = 1, util.slen(src) do
    local char = string.sub(src, index, index)
    if char == "<" then
      inTag = true
    elseif char == ">" then
      inTag = false
    elseif not inTag then
      out[#out + 1] = char
    end
  end
  return util.unescape(table.concat(out))
end

--- 补全协议相对 / http 链接。
function util.https(url)
  local text = util.str(url)
  if text == "" then return nil end
  if text:sub(1, 2) == "//" then return "https:" .. text end
  if text:sub(1, 5) == "http:" then return "https:" .. text:sub(6) end
  return text
end

--- 解析时长。搜索接口给的是 "MM:SS"，其余接口给的是秒数。
function util.durationMs(value)
  if value == nil then return 0 end
  if type(value) == "number" then
    -- 大多数接口是秒
    if value <= 0 then return 0 end
    return math.floor(value * 1000)
  end
  local text = util.str(value)
  if text == "" then return 0 end
  -- "MM:SS" 或 "H:MM:SS"，按冒号切分后逐段累计
  local segments = util.split(text, ":")
  local total, count = 0, 0
  for _, part in ipairs(segments) do
    local digits = util.digitsOnly(part)
    if digits ~= "" then
      total = total * 60 + util.int(digits, 0)
      count = count + 1
    end
  end
  if count == 0 then return 0 end
  return total * 1000
end

--- 把秒数格式化成固定两位数字符串（用于时间戳排序）。
function util.pad(value, width)
  local text = util.str(value)
  while #text < width do text = "0" .. text end
  return text
end

--- 深拷贝一个 table（避免插件返回值被后续修改污染）。
function util.copy(value)
  if type(value) ~= "table" then return value end
  local result = {}
  for key, item in pairs(value) do
    result[key] = util.copy(item)
  end
  return result
end

--- 判断 table 是否为空（既没有数组元素也没有键）。
function util.isEmpty(value)
  if type(value) ~= "table" then return true end
  return next(value) == nil
end

--- 把数组里的 nil 洞清理掉，保持顺序（ipairs 遇到 nil 会断）。
function util.compact(list)
  local out = {}
  for _, item in ipairs(list or {}) do
    if item ~= nil then out[#out + 1] = item end
  end
  return out
end

return util
