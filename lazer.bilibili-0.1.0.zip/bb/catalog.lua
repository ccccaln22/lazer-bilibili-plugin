-- 目录与播放
-- 搜索、视频详情、音频流、字幕、UP 主、评论。

local config = require("bb.config")
local util = require("bb.util")
local transport = require("bb.transport")
local models = require("bb.models")

local catalog = {}

--- 搜索类接口的分页参数（B 站 search/type 单页有硬上限）。
local function pageArgs(args, fallbackLimit)
  local limit = util.int(args and args.limit, fallbackLimit or config.pageDefault)
  if limit < 1 then limit = fallbackLimit or config.pageDefault end
  if limit > config.searchPageMax then limit = config.searchPageMax end
  local offset = util.int(args and args.offset, 0)
  if offset < 0 then offset = 0 end
  local page = math.floor(offset / limit) + 1
  return limit, offset, page
end

--- 列表类分页参数。
--
-- 绝不能像 pageArgs 那样按 searchPageMax 截断：宿主按 limit=100 拉歌单，
-- 这里若只返回 50 条，宿主会认为 items.length(50) < limit(100) 已经到底，
-- 于是收藏夹/歌单只有前 50 首能播。上限放宽到宿主允许的最大页。
local function listArgs(args, fallbackLimit)
  local limit = util.int(args and args.limit, fallbackLimit or 100)
  if limit < 1 then limit = fallbackLimit or 100 end
  if limit > 500 then limit = 500 end
  local offset = util.int(args and args.offset, 0)
  if offset < 0 then offset = 0 end
  return limit, offset
end

--- 视频详情（view）。返回 data 或 nil+err。
local function viewOf(bvid)
  local id = util.str(bvid)
  if id == "" then return nil, "缺少视频 ID" end
  local params = {}
  if id:sub(1, 2) == "av" then
    params.aid = util.str(id:sub(3))
  else
    params.bvid = id
  end
  local data, err = transport.request({
    path = "/x/web-interface/view",
    params = params,
    signed = false,
  })
  if not data then return nil, err end
  return data
end

-- ------------------------------------------------------------------ 搜索

--- 搜索视频 / UP 主 / 合集。
-- B 站 search/type 必须走 WBI，分页 page/page_size。
function catalog.search(args)
  local query = util.str(args and args.query)
  if query == "" then return { songs = {}, artists = {}, playlists = {}, albums = {} } end
  local limit, offset, page = pageArgs(args, 30)
  local songs, artists = {}, {}

  local videos = transport.request({
    path = "/x/web-interface/wbi/search/type",
    params = {
      search_type = "video",
      keyword = query,
      page = page,
      page_size = limit,
    },
    signed = true,
    noAuth = false,
  })
  if type(videos) == "table" and type(videos.result) == "table" then
    for _, item in ipairs(videos.result) do
      if type(item) == "table" and item.bvid then
        local song = models.song(item)
        if song then songs[#songs + 1] = song end
      end
    end
  end

  -- 只在第一页带 UP 主与合集，避免每次翻页都多打两个请求
  if page == 1 then
    local users = transport.request({
      path = "/x/web-interface/wbi/search/type",
      params = {
        search_type = "bili_user",
        keyword = query,
        page = 1,
        page_size = 9,
      },
      signed = true,
    })
    if type(users) == "table" and type(users.result) == "table" then
      for _, item in ipairs(users.result) do
        local artist = models.artist(item)
        if artist then artists[#artists + 1] = artist end
      end
    end
  end

  return {
    songs = songs,
    albums = {},
    artists = artists,
    playlists = {},
  }
end

-- ------------------------------------------------------------------ 单曲

--- 视频 -> 歌曲模型
function catalog.song(args)
  local data, err = viewOf(args and args.id)
  if not data then
    return { error = { code = 70 } }, err
  end
  local song = models.song(data)
  if not song then return { error = { code = 70 } } end
  return song
end

-- ------------------------------------------------------------------ 音频流

--- 播放地址。B 站视频音轨在 dash.audio 里，按 quality 选档。
-- 返回 {url, contentType, suffix, bitRate, size, headers}。
local function pickAudio(dash, quality)
  if type(dash) ~= "table" then return nil end
  local tracks = dash.audio
  if type(tracks) ~= "table" or #tracks == 0 then
    -- 老接口 / flac 单轨兜底
    tracks = dash.dolby and dash.dolby.audio or nil
  end
  if type(tracks) ~= "table" or #tracks == 0 then return nil end

  -- B 站每档音频对应该音轨 id，这里按带宽降序，再按偏好挑
  local sorted = {}
  for _, track in ipairs(tracks) do
    if type(track) == "table" and util.str(track.baseUrl or track.base_url) ~= "" then
      sorted[#sorted + 1] = track
    end
  end
  if #sorted == 0 then return nil end
  table.sort(sorted, function(a, b)
    return util.int(a.bandwidth, 0) > util.int(b.bandwidth, 0)
  end)

  -- dash 的 audio.id 与 qn 不是同一套（30280 ≈ 192K），只能按带宽排序后按档位取
  local chosen = sorted[1]
  if quality == "low" then
    chosen = sorted[#sorted]
  elseif quality == "medium" then
    chosen = sorted[math.min(2, #sorted)]
  elseif quality == "high" then
    chosen = sorted[1]
  else
    -- original：优先 Hi-Res / 杜比，其次最大带宽
    for _, track in ipairs(sorted) do
      local id = util.int(track.id, 0)
      if config.audioQualityIds[id] == "Hi-Res" or config.audioQualityIds[id] == "Dolby" then
        chosen = track
        break
      end
    end
  end

  local url = util.str(chosen.baseUrl or chosen.base_url)
  if url == "" then return nil end
  -- dash 通常还会给 backupUrl，优先用第一个，CDN 挂了宿主会换
  local backups = chosen.backupUrl or chosen.backup_url
  if type(backups) == "table" and type(backups[1]) == "string" and backups[1] ~= "" then
    url = backups[1]
  end

  local suffix = "m4s"
  local mimeType = util.str(chosen.mimeType or chosen.mime_type)
  if mimeType:find("flac", 1, true) then suffix = "flac"
  elseif mimeType:find("mp4", 1, true) then suffix = "m4a" end

  return {
    url = util.https(url),
    contentType = mimeType ~= "" and mimeType or "audio/mp4",
    suffix = suffix,
    bitRate = math.floor(util.int(chosen.bandwidth, 0) / 1000),
  }
end

--- 取播放地址。B 站要求 Referer，宿主会把 headers 一并带上。
function catalog.stream(args)
  local id = util.str(args and args.id)
  if id == "" then return { error = { code = 70 } } end

  local data, err = viewOf(id)
  if not data then
    return { error = { code = 70, httpStatus = 400 } }, err
  end
  local aid = util.int(data.aid, 0)
  -- 多 P 视频默认第一 P
  local cid = util.int(data.cid, 0)
  if cid == 0 and type(data.pages) == "table" and data.pages[1] then
    cid = util.int(data.pages[1].cid, 0)
  end
  if aid == 0 or cid == 0 then return { error = { code = 70 } } end

  local quality = util.str(args and args.quality)
  local qn = config.qnByQuality[quality] or 127

  local play = transport.request({
    path = "/x/player/wbi/playurl",
    params = {
      avid = aid,
      cid = cid,
      qn = qn,
      fnval = 4048,     -- dash + 杜比 + 无损 + 8K
      fnver = 0,
      fourk = 1,
      platform = "pc",
      high_quality = 1,
    },
    signed = true,
  })

  if type(play) ~= "table" then
    return { error = { code = 70, httpStatus = 403 } }
  end

  local picked = pickAudio(play.dash, quality)
  if not picked then return { error = { code = 70 } } end

  picked.headers = {
    ["Referer"] = "https://www.bilibili.com/",
    ["User-Agent"] = config.userAgent,
  }
  picked.transcoded = false
  return picked
end

-- ------------------------------------------------------------------ 字幕 / 歌词

--- 字幕转 LRC。B 站字幕是 JSON：{body:[{from,to,content}]}
local function subtitleToLrc(body)
  if type(body) ~= "table" then return nil, {} end
  local lines = {}
  for _, item in ipairs(body) do
    if type(item) == "table" then
      local text = util.str(item.content)
      local from = tonumber(item.from) or 0
      if text ~= "" then
        lines[#lines + 1] = { text = text, startMs = math.floor(from * 1000) }
      end
    end
  end
  if #lines == 0 then return nil, {} end
  local parts = {}
  for _, line in ipairs(lines) do
    local ms = line.startMs
    local minute = math.floor(ms / 60000)
    local second = math.floor((ms % 60000) / 1000)
    local centi = math.floor((ms % 1000) / 10)
    parts[#parts + 1] = string.format(
      "[%02d:%02d.%02d]%s",
      minute, second, centi, line.text
    )
  end
  return table.concat(parts, "\n"), lines
end

--- 取视频字幕当歌词。没字幕时返回空数组（宿主会提示无歌词）。
function catalog.lyrics(args)
  local id = util.str(args and args.id)
  if id == "" then return {} end

  local data = viewOf(id)
  if not data then return {} end
  local aid = util.int(data.aid, 0)
  local cid = util.int(data.cid, 0)
  if cid == 0 and type(data.pages) == "table" and data.pages[1] then
    cid = util.int(data.pages[1].cid, 0)
  end
  if aid == 0 or cid == 0 then return {} end

  local info = transport.request({
    path = "/x/player/wbi/v2",
    params = { aid = aid, cid = cid },
    signed = true,
  })
  if type(info) ~= "table" then return {} end
  local subtitle = type(info.subtitle) == "table" and info.subtitle or {}
  local tracks = subtitle.subtitles
  if type(tracks) ~= "table" or #tracks == 0 then return {} end

  -- 优先中文，其次第一个
  local chosen = tracks[1]
  for _, track in ipairs(tracks) do
    local lan = util.str(track.lan)
    if lan:find("zh", 1, true) then chosen = track break end
  end

  local url = util.https(chosen.subtitle_url or chosen.subtitleUrl)
  if not url or url == "" then return {} end
  -- 字幕在独立 CDN（aisubtitle.hdslb.com 等），不经 api 域，直接下载
  local subtitleResp = host.http({
    url = url,
    method = "GET",
    headers = {
      ["User-Agent"] = config.userAgent,
      ["Referer"] = config.referer,
    },
  })
  if not subtitleResp or not subtitleResp.body then return {} end
  local ok, parsed = pcall(function() return host.json_decode(subtitleResp.body) end)
  if not ok or type(parsed) ~= "table" then return {} end

  local lrc, lines = subtitleToLrc(parsed.body)
  if not lrc then return {} end

  return {
    {
      lines = lines,
      synced = true,
      lrc = lrc,
      offsetMs = 0,
    },
  }
end

-- ------------------------------------------------------------------ 评论

function catalog.comments(args)
  local id = util.str(args and args.id)
  if id == "" then return { hot = {}, latest = {}, total = 0, hasMore = false } end
  local data = viewOf(id)
  if not data then return { hot = {}, latest = {}, total = 0, hasMore = false } end
  local aid = util.int(data.aid, 0)
  if aid == 0 then return { hot = {}, latest = {}, total = 0, hasMore = false } end

  local limit = util.int(args and args.limit, 20)
  if limit < 1 or limit > 49 then limit = 20 end
  local offset = util.int(args and args.offset, 0)
  local page = math.floor(offset / limit) + 1

  local hot = transport.request({
    path = "/x/v2/reply",
    params = { type = 1, oid = aid, pn = 1, ps = 10, sort = 2 },
    signed = false,
  })

  local latest = transport.request({
    path = "/x/v2/reply",
    params = { type = 1, oid = aid, pn = page, ps = limit, sort = 1 },
    signed = false,
  })

  local function mapList(payload)
    local out = {}
    if type(payload) ~= "table" then return out end
    for _, item in ipairs(payload.replies or {}) do
      local comment = models.comment(item)
      if comment then out[#out + 1] = comment end
    end
    return out
  end

  local hotList = mapList(hot)
  local latestList = mapList(latest)
  local total = 0
  local hasMore = false
  if type(latest) == "table" then
    local pageInfo = latest.page
    if type(pageInfo) == "table" then
      total = util.int(pageInfo.count, 0)
    end
    hasMore = #latestList >= limit
  end

  return {
    hot = hotList,
    latest = latestList,
    total = total,
    hasMore = hasMore,
  }
end

--- 点赞 / 取消点赞评论
function catalog.setCommentLiked(args)
  local id = util.str(args and args.id)
  local commentId = util.str(args and args.commentId)
  local liked = args and args.liked == true
  if id == "" or commentId == "" then return { error = { code = 400 } } end
  local data = viewOf(id)
  if not data then return { error = { code = 400 } } end
  local aid = util.int(data.aid, 0)

  local result = transport.request({
    path = "/x/v2/action",
    params = {},
    method = "POST",
    form = {
      type = 1,
      oid = aid,
      rpid = commentId,
      action = liked and 1 or 0,
      csrf = transport.csrf(),
    },
    signed = false,
  })
  if result == nil then return { error = { code = 70 } } end
  return true
end

-- ------------------------------------------------------------------ 歌手

--- UP 主信息。space 的 wbi 接口风控较严，优先用 card（不需要签名）。
function catalog.artist(args)
  local mid = util.str(args and args.id)
  if mid == "" then return { error = { code = 400 } } end

  local data = transport.request({
    path = "/x/web-interface/card",
    params = { mid = mid, photo = "false" },
    signed = false,
  })
  if type(data) ~= "table" or type(data.card) ~= "table" then
    return { error = { code = 70 } }
  end
  local card = data.card
  return {
    id = util.str(card.mid),
    name = util.str(card.name),
    coverUrl = util.https(card.face),
    description = util.str(card.sign),
    albumCount = util.int(data.archive_count, 0),
  }
end

--- UP 主投稿。B 站 space 接口对匿名请求风控严格（412/-352），
--- 这里用 search 接口按 UP 名检索兜底，保证功能可用。
function catalog.artistSongs(args)
  local mid = util.str(args and args.id)
  if mid == "" then return {} end
  local limit, offset, page = pageArgs(args, 50)

  local card = transport.request({
    path = "/x/web-interface/card",
    params = { mid = mid, photo = "false" },
    signed = false,
  })
  local name = ""
  if type(card) == "table" and type(card.card) == "table" then
    name = util.str(card.card.name)
  end
  if name == "" then return {} end

  local data = transport.request({
    path = "/x/web-interface/wbi/search/type",
    params = {
      search_type = "video",
      keyword = name,
      page = page,
      page_size = limit,
      order = "pubdate",
    },
    signed = true,
  })
  local songs = {}
  if type(data) == "table" and type(data.result) == "table" then
    for _, item in ipairs(data.result) do
      -- search 结果是模糊匹配，只保留确实是这个 UP 主的稿件
      if util.str(item.mid) == mid then
        local song = models.song(item)
        if song then songs[#songs + 1] = song end
      end
    end
  end
  return songs
end

--- B 站没有专辑概念，返回空页。
function catalog.artistAlbums(args)
  return {}
end

-- 收藏夹分页上限。B 站 /x/v3/fav/resource/list 的 ps 最大 40，
-- 传 100 会直接 -400（宿主永远按 100 一页来要，所以这里必须自己切）。
local FAV_PAGE_MAX = 40

-- 单次调用最多翻几页。宿主按 limit=100 一页来拉，而接口单页上限 40，
-- 所以 100 条至少要翻 3 页；留几个余量给"失效视频被跳过"的情况。
-- 上限设 10 是为了防止接口异常时无限翻页，正常 3~4 次就够。
local HARD_PAGE_LIMIT = 10

--- 取收藏夹某一页歌曲。
--
-- 三个坑：
-- 1. B 站 /x/v3/fav/resource/list 的 ps 上限是 40，传 100 直接 -400；
--    而宿主永远按 limit=100 来要，所以这里必须自己拆成多段拼起来。
-- 2. 收藏夹里常有"已失效视频"（attr ~= 0），models.favoriteSong 会跳过。
--    因此不能用"转换后的歌曲数"来推进游标，要用原始条目数，
--    否则每页都会少一截、而且会反复请求同一段。
-- 3. 是否到底看接口的 has_more，不看拿到几条。
local function favPageSongs(mediaId, limit, offset)
  local want = limit
  if want < 1 then want = 100 end

  local songs = {}
  local more = true
  -- 全部按"已经拿到的原始条目数"来算游标（不管一页到底给了几条）。
  -- 之前用 pn*40 推算页号，碰上 B 站某页只回 39 条会卡在原地反复请求。
  local fetched = 0        -- 已经跨过的原始条目总数（= 下次从第几条开始）
  local needSkip = offset  -- 本次要跳过多少条
  local pn = math.floor(offset / FAV_PAGE_MAX) + 1
  local skipInPage = offset % FAV_PAGE_MAX
  local pages = 0

  while #songs < want and pages < HARD_PAGE_LIMIT do
    pages = pages + 1

    local data = transport.request({
      path = "/x/v3/fav/resource/list",
      params = {
        media_id = mediaId,
        pn = pn,
        ps = FAV_PAGE_MAX,
        platform = "web",
        keyword = "",
        order = "mtime",
        type = 0,
        tid = 0,
      },
      signed = false,
    })
    if type(data) ~= "table" or type(data.medias) ~= "table" then
      more = true
      break
    end

    local batch = data.medias
    local count = #batch
    if count == 0 then
      more = false
      break
    end

    for index = skipInPage + 1, count do
      if #songs >= want then break end
      local song = models.favoriteSong(batch[index])
      if song then songs[#songs + 1] = song end
    end

    -- 下一页；页内偏移清零
    pn = pn + 1
    skipInPage = 0
    more = data.has_more == true
    if not more then break end
  end

  return songs, more
end

-- ------------------------------------------------------------------ 歌单 / 收藏夹

--- 分区歌单详情。id 形如 "zone:<rid>"。
local function zonePlaylist(rid)
  local zone = config.zoneById[util.int(rid, -1)]
  if not zone then return nil end
  return {
    id = "zone:" .. util.str(zone.rid),
    name = zone.name,
    description = "哔哩哔哩「" .. zone.name .. "」分区最新投稿",
    writable = false,
    isPublic = true,
  }
end

--- 解析 "zone:<rid>"，返回数字 rid 或 nil。
-- 不用模式匹配：宿主 VM 的 gmatch/gsub 不可靠。
local function zoneRidOf(value)
  local id = util.str(value)
  if not util.startsWith(id, "zone:") then return nil end
  local rest = string.sub(id, 6)
  if not util.isDigits(rest) then return nil end
  return tonumber(rest)
end

--- 解析 "fav:<id>" 或纯数字，返回字符串 id 或 nil。
local function favIdOf(value)
  local id = util.str(value)
  if util.startsWith(id, "fav:") then
    local rest = string.sub(id, 5)
    if util.isDigits(rest) then return rest end
    return nil
  end
  if util.isDigits(id) then return id end
  return nil
end

-- 分区投稿缓存：rid -> {at=毫秒, items=歌曲数组}
local zoneCache = {}
local ZONE_TTL_MS = 5 * 60 * 1000

--- 拉取某分区的投稿（最多 50 条），带 5 分钟缓存。
local function zoneSongs(rid)
  local cached = zoneCache[rid]
  if cached and (host.now() - cached.at) < ZONE_TTL_MS then
    return cached.items
  end
  local data = transport.request({
    path = "/x/web-interface/newlist",
    params = { rid = rid, pn = 1, ps = 50, type = 0 },
    signed = false,
  })
  local items = {}
  if type(data) == "table" and type(data.archives) == "table" then
    for _, item in ipairs(data.archives) do
      local song = models.song(item)
      if song then items[#items + 1] = song end
    end
  end
  zoneCache[rid] = { at = host.now(), items = items }
  return items
end

--- 收藏夹详情。id 是收藏夹 media_id。
local function favPlaylist(mediaId, writable)
  local info = transport.request({
    path = "/x/v3/fav/folder/info",
    params = { media_id = mediaId },
    signed = false,
  })
  if type(info) ~= "table" then return nil end
  local folder = info.info
  if type(folder) ~= "table" then folder = info end
  local id = util.str(folder.id or folder.media_id or mediaId)
  if id == "" then return nil end
  return {
    id = id,
    name = util.str(folder.title or "收藏夹"),
    description = util.str(folder.intro or folder.description),
    coverUrl = util.https(folder.cover),
    songCount = util.int(folder.media_count or folder.count, 0),
    owner = util.str(folder.mid or folder.upper and folder.upper.mid),
    writable = writable == true,
    isPublic = folder.attr == nil or util.int(folder.attr, 0) == 0,
  }
end

--- 歌单详情：排行榜或收藏夹。
function catalog.playlist(args)
  local id = util.str(args and args.id)
  if id == "" then return { error = { code = 400 } } end

  local rid = zoneRidOf(id)
  if rid then
    local playlist = zonePlaylist(rid)
    if playlist then return playlist end
    return { error = { code = 70 } }
  end

  local mediaId = favIdOf(id)
  if not mediaId then return { error = { code = 400 } } end
  local playlist = favPlaylist(mediaId, transport.loggedIn())
  if playlist then return playlist end
  return { error = { code = 70 } }
end

--- 歌单内容：排行榜或收藏夹。
function catalog.playlistSongs(args)
  local id = util.str(args and args.id)
  if id == "" then return {} end
  local limit, offset = listArgs(args, 100)

  local rid = zoneRidOf(id)
  if rid then
    -- newlist 的 pn 参数已被服务端忽略（返回的 page.num 恒为 1），
    -- 所以一次取满 50 条缓存起来，再按 offset 本地切片。
    local songs = zoneSongs(tonumber(rid))
    local out = {}
    for index = offset + 1, math.min(offset + limit, #songs) do
      out[#out + 1] = songs[index]
    end
    return out
  end

  local mediaId = favIdOf(id)
  if not mediaId then return {} end

  local songs = favPageSongs(mediaId, limit, offset)
  -- 宿主按 list.length >= limit 判定还有下一页。
  -- 到底了就让它短于 limit，别硬凑。
  return songs
end

--- 供 discover 复用的收藏夹分页入口（args.media_id / limit / offset）。
function catalog.favoriteSongs(args)
  local mediaId = util.str(args and args.media_id)
  if mediaId == "" then return {} end
  local limit = util.int(args and args.limit, 100)
  if limit < 1 then limit = 100 end
  local offset = util.int(args and args.offset, 0)
  if offset < 0 then offset = 0 end
  local songs, more, cursor = favPageSongs(mediaId, limit, offset)
  return songs, more, cursor
end

return catalog
