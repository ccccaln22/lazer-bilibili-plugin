-- 哔哩哔哩 Gateway 常量表
-- 所有与 B 站协议相关的固定值集中在这里，其余模块只读不写。

local config = {}

-- 接口域名
config.apiHost = "api.bilibili.com"
config.passportHost = "passport.bilibili.com"
config.appHost = "app.bilibili.com"

-- 伪装成普通浏览器，B 站对空 UA 会直接 412
config.userAgent =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " ..
  "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
config.referer = "https://www.bilibili.com/"
config.origin = "https://www.bilibili.com"

-- 存储键
config.cookieKey = "bb_cookie"
config.buvidKey = "bb_buvid"

-- WBI 签名混排表（B 站 wbi 固定 64 项，取前 32 位作为 mixin key）
config.wbiMixin = {
  46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
  27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
  37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
  22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
}

-- WBI 密钥缓存时长（毫秒）。B 站每天轮换一次，留点余量。
config.wbiTtlMs = 10 * 60 * 1000

-- 音质档位 -> 期望的 qn 值。B 站实际返回取决于账号权限，这里只作为偏好。
config.qnByQuality = {
  original = 127,
  high = 80,
  medium = 64,
  low = 32,
}

-- dash.audio 的 id 含义（用于在带宽接近时挑更"值"的档位）
config.audioQualityIds = {
  [30216] = "64K",
  [30232] = "132K",
  [30280] = "192K",
  [30250] = "Dolby",
  [30251] = "Hi-Res",
}

-- 分区歌单（charts）。用的 /x/web-interface/newlist?rid= 接口，
-- 只有带真实 rid 的分区才有效；1005 是虚拟综合区，接口会 400，别加。
config.rankZones = {
  { rid = 3, name = "音乐区" },
  { rid = 1, name = "动画区" },
  { rid = 4, name = "游戏区" },
  { rid = 129, name = "舞蹈区" },
  { rid = 36, name = "科技区" },
  { rid = 188, name = "数码区" },
  { rid = 181, name = "影视区" },
  { rid = 5, name = "娱乐区" },
  { rid = 119, name = "鬼畜区" },
}

-- 按 rid 反查，避免每次遍历
config.zoneById = {}
for _, zone in ipairs(config.rankZones) do
  config.zoneById[zone.rid] = zone
end

-- homeFeed / radio 默认取多少条
config.pageDefault = 30
-- search/type 单页硬上限
config.searchPageMax = 50

return config
