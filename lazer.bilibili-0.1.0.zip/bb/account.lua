-- 账号与登录
-- 支持扫码（web 端 qrcode_key）和 Cookie 导入两种方式。

local config = require("bb.config")
local util = require("bb.util")
local transport = require("bb.transport")

local account = {}

local USER_KEY = "bb_user"

local function cachedUser()
  local raw = host.storage_get(USER_KEY)
  if type(raw) ~= "string" or raw == "" then return nil end
  local ok, parsed = pcall(function() return host.json_decode(raw) end)
  if ok and type(parsed) == "table" then return parsed end
  return nil
end

local function saveUser(user)
  if user then
    host.storage_set(USER_KEY, host.json_encode(user))
  else
    host.storage_set(USER_KEY, nil)
  end
end

--- 用当前 Cookie 拉一次 nav，成功即视为登录态有效。
local function fetchNav()
  local data, err = transport.request({
    path = "/x/web-interface/nav",
    params = {},
    signed = false,
  })
  if not data then return nil, err end
  return data
end

--- 把 nav 返回的 data 转成 Lazer 的 MusicUser。
local function toUser(nav)
  if type(nav) ~= "table" or nav.isLogin ~= true then return nil end
  local mid = util.str(nav.mid)
  if mid == "" then return nil end
  return {
    id = mid,
    name = util.str(nav.uname) ~= "" and util.str(nav.uname) or ("B站用户" .. mid),
    avatarUrl = util.https(nav.face),
    signature = util.str(nav.sign),
    membership = nav.vipStatus == 1 and "大会员" or nil,
  }
end

function account.session()
  if not transport.loggedIn() then
    saveUser(nil)
    return nil
  end
  local nav, err = fetchNav()
  local user = toUser(nav)
  if user then
    saveUser(user)
    return user
  end
  -- nav 失败但 cookie 还在：先给缓存身份，避免播放中途把人踢下线
  if err then
    local cached = cachedUser()
    if cached then return cached end
  end
  return nil
end

function account.logout()
  transport.clear()
  saveUser(nil)
  return {}
end

--- 生成扫码 key，并把登录用 URL 记下来。
-- 宿主扫码流程：qrKey -> qrUrl(key) -> 轮询 qrCheck(key)。
local qrSessions = {}

function account.qrKey()
  local data = transport.request({
    hostname = config.passportHost,
    path = "/x/passport-login/web/qrcode/generate",
    params = {},
    noAuth = true,
  })
  if type(data) ~= "table" then return nil end
  local key = util.str(data.qrcode_key)
  if key == "" then return nil end
  qrSessions[key] = util.str(data.url)
  return key
end

function account.qrUrl(args)
  local key = util.str(args and args.key)
  if key == "" then return "" end
  local session = qrSessions[key]
  if session and session ~= "" then return session end
  -- 进程重启后 qrSessions 丢了，B 站的扫码 URL 需要 key 本身，
  -- 用官方 h5 页兜底，扫码端会跳回 bilibili 授权。
  return "https://passport.bilibili.com/h5-app/passport/login/scan?qrcode_key=" ..
    host.url_encode(key)
end

--- 轮询扫码状态。
-- B 站返回 code：0 成功 / 86038 已失效 / 86090 已扫码待确认 / 86101 未扫码
-- 映射到宿主的 801/802/803/800 契约。
function account.qrCheck(args)
  local key = util.str(args and args.key)
  if key == "" then return 800 end

  local resp = transport.request({
    hostname = config.passportHost,
    path = "/x/passport-login/web/qrcode/poll",
    params = { qrcode_key = key },
    noAuth = true,
    raw = true,
  })
  if type(resp) ~= "table" or not resp.body or resp.body == "" then
    return 801
  end

  local ok, parsed = pcall(function() return host.json_decode(resp.body) end)
  if not ok or type(parsed) ~= "table" then return 801 end

  -- 成功这次响应的 Set-Cookie 里才有 SESSDATA，必须在 raw 请求后吸收
  transport.absorb(resp)

  local payload = type(parsed.data) == "table" and parsed.data or {}
  local code = util.int(payload.code, -1)

  if code == 0 then
    qrSessions[key] = nil
    -- 有些情况下 poll 的 data.url 里也带 cookie 参数，保险起见再解析一遍
    local url = util.str(payload.url)
    if url ~= "" then
      -- 手工解析 ?a=b&c=d，不用 gmatch/gsub（宿主 VM 不可靠）
      local query = ""
      local question = string.find(url, "?", 1, true)
      if question then query = string.sub(url, question + 1) end
      local wanted = {}
      for _, pair in ipairs(util.split(query, "&")) do
        local eq = string.find(pair, "=", 1, true)
        if eq then
          local name = string.sub(pair, 1, eq - 1)
          local value = string.sub(pair, eq + 1)
          if name == "SESSDATA" or name == "bili_jct" or
              name == "DedeUserID" or name == "DedeUserID__ckMd5" or name == "sid" then
            -- 值里的 %3D 还原成 =，其余交给 cookie_compact
            wanted[#wanted + 1] = name .. "=" .. util.replace(host.url_encode(value), "%3D", "=")
          end
        end
      end
      if #wanted > 0 then
        transport.adoptCookie(table.concat(wanted, "; "))
      end
    end
    local user = account.session()
    return user and 803 or 803
  elseif code == 86090 then
    return 802
  elseif code == 86038 then
    qrSessions[key] = nil
    return 800
  elseif code == 86101 then
    return 801
  end
  -- 86101=未扫码；其余未知状态继续等
  return 801
end

--- 用户粘贴 Cookie 登录。
function account.loginCookie(args)
  local raw = util.str(args and args.cookie)
  if raw == "" then return nil end
  transport.adoptCookie(raw)
  if not transport.loggedIn() then return nil end
  local user = account.session()
  return user
end

--- 导出当前 Cookie（manifest 声明了 exportCookie 才有入口）。
function account.exportCookie()
  return transport.cookie()
end

return account
