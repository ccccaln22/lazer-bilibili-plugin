-- WBI 签名
-- B 站大部分 web 接口要 wts + w_rid，密钥从 nav 的 wbi_img 里取，
-- 每天轮换，本地缓存 10 分钟足够。

local config = require("bb.config")
local util = require("bb.util")

local wbi = {}

local cached = nil
local cachedAt = 0

--- 从 https://i0.hdslb.com/bfs/wbi/xxxx.png 里取出 xxxx。
-- 不用 match/gsub：宿主 VM 的模式引擎不可靠（gsub 直接失效）。
local function extractKey(url)
  local name = util.afterLast(util.str(url), "/")
  if util.endsWith(name, ".png") then
    name = string.sub(name, 1, util.slen(name) - 4)
  end
  return name
end

--- 请求 nav 拿 img/sub 两个 key。未登录也会返回，所以匿名可签。
local function fetchKeys()
  local resp = host.http({
    url = "https://" .. config.apiHost .. "/x/web-interface/nav",
    method = "GET",
    headers = {
      ["User-Agent"] = config.userAgent,
      ["Referer"] = config.referer,
      ["Accept"] = "application/json, text/plain, */*",
    },
  })
  if not resp or not resp.body then return nil end
  local ok, parsed = pcall(function() return host.json_decode(resp.body) end)
  if not ok or type(parsed) ~= "table" then return nil end
  local data = parsed.data
  if type(data) ~= "table" or type(data.wbi_img) ~= "table" then return nil end
  local imgKey = extractKey(data.wbi_img.img_url)
  local subKey = extractKey(data.wbi_img.sub_url)
  -- 注意用 util.slen 而不是 #：宿主 VM 对字符串取长度有缺陷
  if util.slen(imgKey) ~= 32 or util.slen(subKey) ~= 32 then return nil end
  return { img = imgKey, sub = subKey }
end

--- 按混排表取 32 位盐
local function mixinOf(keys)
  local joined = keys.img .. keys.sub
  if util.slen(joined) < 64 then return nil end
  local parts = {}
  for index, position in ipairs(config.wbiMixin) do
    parts[index] = joined:sub(position + 1, position + 1)
  end
  return table.concat(parts)
end

function wbi.keys()
  if cached and (host.now() - cachedAt) < config.wbiTtlMs then
    return cached
  end
  local stored = host.storage_get("bb_wbi")
  local storedAt = tonumber(host.storage_get("bb_wbi_at")) or 0
  if type(stored) == "table" and stored.img and stored.sub then
    if (host.now() - storedAt) < config.wbiTtlMs then
      cached, cachedAt = stored, storedAt
      return cached
    end
  end
  local fresh = fetchKeys()
  if fresh then
    cached, cachedAt = fresh, host.now()
    host.storage_set("bb_wbi", fresh)
    host.storage_set("bb_wbi_at", cachedAt)
    return cached
  end
  -- 刷新失败时退回到旧值（过期密钥仍比完全没签名强）
  if type(stored) == "table" and stored.img and stored.sub then
    cached, cachedAt = stored, storedAt
    return cached
  end
  return nil
end

--- 给参数补 wts/w_rid，返回可直接拼进 URL 的查询串。
-- wts 必须先并入参数表再排序，否则服务端算出来的串和这里不一致。
function wbi.sign(params)
  local keys = wbi.keys()
  if not keys then return nil end
  local salt = mixinOf(keys)
  if not salt then return nil end
  local merged = {}
  for key, value in pairs(params) do merged[key] = value end
  merged["wts"] = util.nowSec()
  local query = util.query(merged)
  local rid = util.md5(query .. salt)
  return query .. "&w_rid=" .. rid
end

--- 丢掉缓存（cookie 变化、401 之后调用）
function wbi.invalidate()
  cached, cachedAt = nil, 0
  host.storage_set("bb_wbi", nil)
  host.storage_set("bb_wbi_at", nil)
end

return wbi
