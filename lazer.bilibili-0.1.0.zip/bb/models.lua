-- 模型映射：把 B 站各种五花八门的结构归一成 Lazer 的通用模型。
-- 思路：能拿到的字段尽量对齐，拿不到的宁缺勿造。

local util = require("bb.util")

local models = {}

--- BV 号 -> 歌曲 id。同时保留 aid 供内部拼接。
-- B 站视频的 bvid 是跨接口稳定的标识，所有取单曲信息的接口都接受它。
local function videoId(item)
  local bvid = util.str(item.bvid)
  if bvid ~= "" then return bvid end
  local aid = util.int(item.aid or item.avid or item.id, 0)
  if aid > 0 then return "av" .. util.str(aid) end
  return ""
end

--- 从 title 里粗提一个"歌手"，B 站在音乐区习惯写 "【歌手】歌名" 或 "歌手 - 歌名"。
-- 这只是关键词级别的启发，不追求准确；UP 主始终作为第一歌手。
local function guessArtists(title, owner)
  local artists = {}
  local ownerName = util.str(owner and owner.name)
  local ownerId = util.str(owner and owner.mid)
  if ownerName ~= "" then
    artists[#artists + 1] = { id = ownerId ~= "" and ownerId or ownerName, name = ownerName }
  end
  return artists
end

--- 通用视频 -> 歌曲模型。
-- 兼容：view / ranking / rcmd / popular / search 五种返回结构。
function models.song(item, extra)
  if type(item) ~= "table" then return nil end
  local id = videoId(item)
  if id == "" then return nil end

  local title = util.stripTags(item.title)
  if title == "" then title = "未命名视频" end

  local owner = type(item.owner) == "table" and item.owner or nil
  if not owner then
    -- search 接口把 UP 主平铺成 author / mid / upic
    local author = util.str(item.author or item.uname)
    if author ~= "" then
      owner = { name = author, mid = item.mid or item.uid, face = item.upic or item.uface }
    end
  end

  local artists = guessArtists(title, owner)
  local cover = util.https(item.pic or item.first_frame or (type(owner) == "table" and owner.face))

  local durationMs = 0
  if item.duration ~= nil then
    durationMs = util.durationMs(item.duration)
  elseif item.timelength ~= nil then
    durationMs = util.int(item.timelength, 0)
  end

  local song = {
    id = id,
    title = title,
    artists = artists,
    coverUrl = cover,
    durationMs = durationMs,
    starred = extra and extra.starred == true or false,
  }

  -- 专辑概念在 B 站不存在，用分区名兜底当"专辑"，列表里能看出分类
  local zone = util.str(item.tname or item.typename)
  if zone ~= "" and zone ~= "-" then
    song.albumId = "zone:" .. zone
    song.albumName = zone
  end

  if type(item.stat) == "table" then
    song.playCount = util.int(item.stat.view, 0)
  elseif item.play ~= nil then
    song.playCount = util.int(item.play, 0)
  end

  return song
end

--- UP 主 -> 歌手模型
function models.artist(item)
  if type(item) ~= "table" then return nil end
  local mid = util.str(item.mid or item.uid or (item.card and item.card.mid))
  if mid == "" then return nil end
  local name = util.str(item.uname or item.name or (item.card and item.card.name))
  if name == "" then name = "UP主" .. mid end
  local avatar = util.https(
    item.upic or item.face or (item.card and item.card.face)
  )
  local sign = util.str(item.usign or item.sign or (item.card and item.card.sign))
  return {
    id = mid,
    name = name,
    coverUrl = avatar,
    description = sign,
    albumCount = util.int(item.videos or (item.card and item.card.archive_count), nil),
  }
end

--- 收藏夹 / 排行榜 -> 歌单模型
function models.playlist(item, options)
  options = options or {}
  if type(item) ~= "table" then return nil end
  local id = util.str(item.id or item.media_id or item.rid)
  if id == "" then return nil end
  local cover = util.https(item.cover or item.pic)
  return {
    id = id,
    name = util.str(item.title or item.name or "未命名歌单"),
    description = util.str(item.intro or item.description or item.desc),
    coverUrl = cover,
    songCount = util.int(item.media_count or item.count or item.total, 0),
    owner = util.str(item.mid or item.upper and item.upper.mid),
    writable = options.writable == true,
    isPublic = item.attr == nil or util.int(item.attr, 0) == 0,
    isFavorites = options.isFavorites == true,
  }
end

--- 分区 -> 歌单（charts 用）
function models.zonePlaylist(zone)
  return {
    id = "zone:" .. util.str(zone.rid),
    name = util.str(zone.name),
    description = "哔哩哔哩「" .. util.str(zone.name) .. "」分区最新投稿",
    songCount = 0,
    writable = false,
    isPublic = true,
  }
end

--- 收藏夹资源 -> 歌曲（resource 结构和 view 很像，但 fields 名不同）
function models.favoriteSong(item)
  if type(item) ~= "table" then return nil end
  -- 失效视频会带 attr != 0，跳过
  if item.attr ~= nil and util.int(item.attr, 0) ~= 0 then return nil end
  local song = models.song({
    bvid = item.bvid,
    aid = item.id,
    title = item.title,
    pic = item.cover,
    duration = item.duration,
    owner = { mid = item.upper and item.upper.mid, name = item.upper and item.upper.name },
    pubdate = item.pubtime,
  })
  if song then song.starred = true end
  return song
end

--- 评论
function models.comment(item)
  if type(item) ~= "table" then return nil end
  local member = type(item.member) == "table" and item.member or {}
  local content = type(item.content) == "table" and item.content or {}
  local replies = {}
  if type(item.replies) == "table" then
    for _, reply in ipairs(item.replies) do
      if type(reply) == "table" and type(reply.content) == "table" then
        replies[#replies + 1] = {
          author = util.str((reply.member or {}).uname),
          content = util.str(reply.content.message),
        }
      end
    end
  end
  return {
    id = util.str(item.rpid),
    content = util.str(content.message),
    author = util.str(member.uname),
    authorId = util.str(member.mid),
    avatarUrl = util.https(member.avatar),
    time = util.int(item.ctime, 0) * 1000,
    location = util.str(item.reply_control and item.reply_control.location),
    liked = item.action == 1,
    likedCount = util.int(item.like, 0),
    replies = replies,
  }
end

return models
