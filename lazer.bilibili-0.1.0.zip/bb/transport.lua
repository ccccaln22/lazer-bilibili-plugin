-- 网络与凭据层
-- 统一处理 Cookie 罐、buvid 设备指纹、WBI 签名、表单/JSON 请求和错误映射。

local config = require("bb.config")
local util = require("bb.util")
local wbi = require("bb.wbi")

local transport = {}

-- ---------------------------------------------------------------- Cookie 罐

local function readCookie()
  local stored = host.storage_get(config.cookieKey)
  if type(stored) ~= "string" then return "" end
  return stored
end

local function writeCookie(value)
  local compact = nil
  if value and value ~= "" then
    compact = host.cookie_compact(value)
  end
  host.storage_set(config.cookieKey, compact or "")
  return compact
end

--- 匿名设备指纹。B 站部分接口（尤其 space 系列）会检查 buvid3，
--- 没有就先申请一对存起来，之后带上能让风控宽松一些。
local function ensureBuvid()
  local stored = host.storage_get(config.buvidKey)
  if type(stored) == "string" and stored:find("buvid3=", 1, true) then
    return stored
  end
  local resp = host.http({
    url = "https://" .. config.apiHost .. "/x/frontend/finger/spi",
    method = "GET",
    headers = {
      ["User-Agent"] = config.userAgent,
      ["Referer"] = config.referer,
    },
  })
  local value = nil
  if resp and resp.body then
    local ok, parsed = pcall(function() return host.json_decode(resp.body) end)
    if ok and type(parsed) == "table" and type(parsed.data) == "table" then
      local b3 = util.str(parsed.data.b_3)
      local b4 = util.str(parsed.data.b_4)
      if b3 ~= "" then
        value = "buvid3=" .. b3
        if b4 ~= "" then value = value .. "; buvid4=" .. b4 end
      end
    end
  end
  if value then host.storage_set(config.buvidKey, value) end
  return value
end

--- 当前请求要带的 Cookie。只有真正登录时才带。
--
-- 这里刻意不做"匿名也塞 buvid"的兜底：B 站对带 Cookie 的
-- /x/web-interface/wbi/search/type 请求会返回 `data.v_voucher`
-- （风控票据）而不是搜索结果，曲库因此会是空的。
-- 未登录时宁可裸请求，接口本来就允许匿名访问。
function transport.cookie()
  return readCookie()
end

--- 供内部分接口按需取设备指纹（目前没有调用方，留着备用）。
function transport.deviceCookie()
  return ensureBuvid()
end

--- 用户主动贴进来的 Cookie，规范化后落盘。返回规范化结果。
function transport.adoptCookie(raw)
  local merged = host.cookie_merge(readCookie(), util.str(raw))
  if not merged or merged == "" then merged = host.cookie_compact(util.str(raw)) end
  return writeCookie(merged)
end

--- 从响应头里吸收 Set-Cookie（扫码登录靠它拿 SESSDATA）。
--- 吸收响应 Cookie。只有已经登录（或本次就要落地登录凭据）时才写。
-- 未登录状态下把 buvid 之类的设备 Cookie 存下来，会让后续搜索
-- 被 B 站判定为"可疑客户端"而只返回 v_voucher。
function transport.absorb(resp)
  if not resp or type(resp.headers) ~= "table" then return end
  local setCookie = resp.headers["set-cookie"] or resp.headers["Set-Cookie"]
  if type(setCookie) ~= "string" or setCookie == "" then return end
  -- 扫码成功那次响应里会有 SESSDATA，必须落地
  local hasSession = setCookie:find("SESSDATA", 1, true) ~= nil
  if not hasSession and not transport.loggedIn() then return end
  local merged = host.cookie_merge(readCookie(), setCookie)
  if merged and merged ~= "" then writeCookie(merged) end
end

function transport.csrf()
  return host.cookie_field(readCookie() or "", "bili_jct") or ""
end

function transport.loggedIn()
  local cookie = readCookie()
  if cookie == "" then return false end
  return (host.cookie_field(cookie, "SESSDATA") or "") ~= ""
end

function transport.clear()
  writeCookie("")
  host.storage_set("bb_buvid", nil)
  host.storage_set("bb_wbi", nil)
  host.storage_set("bb_wbi_at", nil)
end

-- ---------------------------------------------------------------- 请求

local function baseHeaders(extra)
  local headers = {
    ["User-Agent"] = config.userAgent,
    ["Referer"] = config.referer,
    ["Origin"] = config.origin,
    ["Accept"] = "application/json, text/plain, */*",
  }
  local cookie = transport.cookie()
  if cookie ~= "" then headers["Cookie"] = cookie end
  for key, value in pairs(extra or {}) do headers[key] = value end
  return headers
end

--- 任务失败时的对等错误表
local function failure(code, httpStatus)
  return { error = { code = code, httpStatus = httpStatus } }
end

--- 核心请求。
-- options:
--   path       接口路径，如 "/x/web-interface/view"
--   params     查询参数表
--   signed     是否走 WBI 签名
--   method     GET / POST
--   form       表单体（table），会自动带上 csrf
--   json       JSON 体（table）
--   hostname   覆盖域名，默认 api.bilibili.com
--   noAuth     禁止带登录 Cookie（公共接口用）
--   raw        返回原始响应而非解析后的 data
-- 返回 (data, resp) 或 (nil, 错误描述, 错误表)
function transport.request(options)
  options = options or {}
  local hostname = options.hostname or config.apiHost
  local path = options.path or "/"
  local method = (options.method or "GET"):upper()
  local params = {}
  for key, value in pairs(options.params or {}) do params[key] = value end

  local query = nil
  if options.signed then
    query = wbi.sign(params)
    if not query then
      return nil, "无法获取签名密钥", failure(503, 503)
    end
  else
    local plain = util.query(params)
    if plain ~= "" then query = plain end
  end

  local url = "https://" .. hostname .. path
  if query and query ~= "" then url = url .. "?" .. query end

  local headers = baseHeaders(options.headers)
  local body = nil

  if options.form then
    local fields = {}
    for key, value in pairs(options.form) do
      fields[#fields + 1] = util.encode(key) .. "=" .. util.encode(value)
    end
    body = table.concat(fields, "&")
    headers["Content-Type"] = "application/x-www-form-urlencoded"
  elseif options.json then
    body = host.json_encode(options.json)
    headers["Content-Type"] = "application/json"
  end

  local spec = { url = url, method = method, headers = headers }
  if body then spec.body = body end

  local ok, resp = pcall(function() return host.http(spec) end)
  if not ok or type(resp) ~= "table" then
    return nil, "网络请求失败", failure(500, 500)
  end
  if not options.noAuth then transport.absorb(resp) end

  if options.raw then return resp, nil, nil end

  if resp.status == 401 or resp.status == 403 then
    return nil, "登录状态失效", failure(41, resp.status)
  end
  if resp.status == 412 then
    -- B 站风控：请求太密或指纹可疑，通常封一会儿 IP。
    -- 归到 429 让宿主按限流处理（保留重试机会），不要误报成"要重新登录"。
    return nil, "触发风控，请稍后再试", failure(429, 429)
  end
  if resp.status == 429 then
    return nil, "请求过于频繁", failure(429, 429)
  end
  if resp.status >= 500 then
    return nil, "服务端错误", failure(resp.status, resp.status)
  end
  if not resp.body or resp.body == "" then
    return nil, "响应为空", failure(502, resp.status)
  end

  local decoded, parsed = pcall(function() return host.json_decode(resp.body) end)
  if not decoded or type(parsed) ~= "table" then
    return nil, "响应格式异常", failure(502, resp.status)
  end
  -- HTTP 200 也可能是风控：B 站用业务码 -412 / -352 表达
  local bizCode = util.int(parsed.code, 0)
  if bizCode == -412 then
    return nil, "触发风控，请稍后再试", failure(429, 429)
  end
  return parsed.data, nil, parsed
end

return transport
