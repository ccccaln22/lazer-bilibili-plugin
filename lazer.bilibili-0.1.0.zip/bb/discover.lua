-- 发现与个人库
-- homeFeed、排行榜、收藏夹、推荐流、相关推荐。

local config = require("bb.config")
local util = require("bb.util")
local transport = require("bb.transport")
local models = require("bb.models")

local discover = {}

--- 搜索/排行榜这类单页有上限的接口
local function pageArgs(args, fallbackLimit)
  local limit = util.int(args and args.limit, fallbackLimit or config.pageDefault)
  if limit < 1 then limit = fallbackLimit or config.pageDefault end
  if limit > 50 then limit = 50 end
  local offset = util.int(args and args.offset, 0)
  if offset < 0 then offset = 0 end
  local page = math.floor(offset / limit) + 1
  return limit, offset, page
end

--- 列表类分页：不能截断。
-- 宿主按 limit=100 拉收藏夹，截成 50 会让它判定 items.length(50) < 100 到底，
-- 结果只剩前 50 首能播。
local function listArgs(args, fallbackLimit)
  local limit = util.int(args and args.limit, fallbackLimit or 100)
  if limit < 1 then limit = fallbackLimit or 100 end
  if limit > 500 then limit = 500 end
  local offset = util.int(args and args.offset, 0)
  if offset < 0 then offset = 0 end
  return limit, offset
end

local function mapSongs(items)
  local songs = {}
  if type(items) ~= "table" then return songs end
  for _, item in ipairs(items) do
    local song = models.song(item)
    if song then songs[#songs + 1] = song end
  end
  return songs
end

-- ------------------------------------------------------------------ 首页

--- 首页聚合：推荐流 + 热门 + 音乐排行榜。
function discover.homeFeed()
  local quick, daily, recommended = {}, {}, {}

  -- 1. 推荐流（wbi 版 rcmd）
  local rcmd = transport.request({
    path = "/x/web-interface/wbi/index/top/feed/rcmd",
    params = {
      ps = 12,
      fresh_type = 4,
      fresh_idx = 1,
      fresh_idx_1h = 1,
      feed_version = "V8",
      homepage_ver = 1,
      brush = 0,
    },
    signed = true,
  })
  if type(rcmd) == "table" and type(rcmd.item) == "table" then
    quick = mapSongs(rcmd.item)
  end

  -- 2. 热门（不需要签名，稳定）
  local popular = transport.request({
    path = "/x/web-interface/popular",
    params = { pn = 1, ps = 12 },
    signed = false,
  })
  if type(popular) == "table" and type(popular.list) == "table" then
    daily = mapSongs(popular.list)
  end

  -- 3. 音乐区最新投稿当作"推荐歌单"
  local latest = transport.request({
    path = "/x/web-interface/newlist",
    params = { rid = 3, pn = 1, ps = 1, type = 0 },
    signed = false,
  })
  local cover = nil
  if type(latest) == "table" and type(latest.archives) == "table" and latest.archives[1] then
    cover = latest.archives[1].pic
  end
  for _, zone in ipairs(config.rankZones) do
    recommended[#recommended + 1] = models.playlist({
      id = "zone:" .. util.str(zone.rid),
      title = zone.name .. " · 最新投稿",
      cover = zone.rid == 3 and cover or nil,
      count = 0,
      description = "哔哩哔哩「" .. zone.name .. "」分区实时更新",
    })
  end

  -- 4. 音乐区热门 UP（拿几个固定音乐官方号当"歌手"）
  local artists = {}
  local users = transport.request({
    path = "/x/web-interface/wbi/search/type",
    params = { search_type = "bili_user", keyword = "音乐", page = 1, page_size = 6 },
    signed = true,
  })
  if type(users) == "table" and type(users.result) == "table" then
    for _, item in ipairs(users.result) do
      local artist = models.artist(item)
      if artist then artists[#artists + 1] = artist end
    end
  end

  return {
    quick = quick,
    daily = daily,
    recommended = recommended,
    playlists = {},
    albums = {},
    featuredSongs = quick,
    editorialPlaylists = {},
  }
end

-- ------------------------------------------------------------------ 排行榜

function discover.charts()
  local out = {}
  for _, zone in ipairs(config.rankZones) do
    out[#out + 1] = models.zonePlaylist(zone)
  end
  return out
end

-- ------------------------------------------------------------------ 收藏夹

--- 取当前登录账号的 mid（收藏夹接口都要用）。
local function myMid()
  local nav = transport.request({
    path = "/x/web-interface/nav",
    params = {},
    signed = false,
  })
  if type(nav) ~= "table" or nav.isLogin ~= true then return nil end
  local mid = util.str(nav.mid)
  if mid == "" then return nil end
  return mid
end

--- 收藏歌曲（"我喜欢"不在 B 站概念里，用默认收藏夹代替）。
function discover.favorites(args)
  if not transport.loggedIn() then return {} end
  local limit, offset = listArgs(args, 100)

  local mid = myMid()
  if not mid then return {} end

  local folders = transport.request({
    path = "/x/v3/fav/folder/created/list-all",
    params = { up_mid = mid },
    signed = false,
  })
  if type(folders) ~= "table" or type(folders.list) ~= "table" then return {} end
  local folder = folders.list[1]
  if type(folder) ~= "table" then return {} end

  -- 复用 catalog 的分页实现（B 站 ps 上限 40，宿主一页要 100）
  local catalog = require("bb.catalog")
  local songs = catalog.favoriteSongs({
    media_id = util.str(folder.id),
    limit = limit,
    offset = offset,
  })
  return songs or {}
end

--- 用户收藏夹列表（当作歌单列表）
function discover.playlists(args)
  if not transport.loggedIn() then return {} end
  local limit, offset = listArgs(args, 100)

  local mid = myMid()
  if not mid then return {} end

  local folders = transport.request({
    path = "/x/v3/fav/folder/created/list-all",
    params = { up_mid = mid },
    signed = false,
  })
  if type(folders) ~= "table" or type(folders.list) ~= "table" then return {} end

  local out = {}
  for index, item in ipairs(folders.list) do
    if index > offset and index <= offset + limit then
      local playlist = models.playlist({
        -- 加 fav: 前缀，和分区歌单的 zone: 区分开，避免 id 撞车
        id = "fav:" .. util.str(item.id),
        title = item.title,
        cover = item.cover,
        count = item.media_count,
        intro = "收藏夹",
        mid = mid,
      }, { writable = true })
      if playlist then out[#out + 1] = playlist end
    end
  end
  return out
end

-- ------------------------------------------------------------------ 推荐

--- 根据当前播放的歌做相关推荐。
function discover.recommendations(args)
  local limit = util.int(args and args.limit, 20)
  if limit < 1 or limit > 50 then limit = 20 end

  local rcmd = transport.request({
    path = "/x/web-interface/wbi/index/top/feed/rcmd",
    params = {
      ps = limit,
      fresh_type = 3,
      fresh_idx = 1,
      fresh_idx_1h = 1,
      feed_version = "V8",
      homepage_ver = 1,
      brush = 0,
    },
    signed = true,
  })
  if type(rcmd) ~= "table" then return {} end
  return mapSongs(rcmd.item)
end

--- radio：kind=seed 时拉相关视频，其余走通用推荐。
function discover.radio(args)
  local kind = util.str(args and args.kind)
  local seed = util.str(args and args.seed)
  local limit = util.int(args and args.limit, 30)
  if limit < 1 or limit > 50 then limit = 30 end

  if kind == "seed" and seed ~= "" then
    local data = transport.request({
      path = "/x/web-interface/archive/related",
      params = { bvid = seed },
      signed = false,
    })
    if type(data) == "table" then return mapSongs(data) end
  end

  return discover.recommendations({ limit = limit })
end

return discover
