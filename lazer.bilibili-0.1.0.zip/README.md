# 哔哩哔哩 · Lazer Lua Gateway 插件

给 [Lazer](https://github.com/chuxuehaocai/Lazer) 音乐播放器加一个哔哩哔哩音源。把视频当音轨听：搜索、播放、字幕歌词、UP 主、收藏夹、分区最新、首页推荐、评论，全都走 B 站 web 接口。

- 插件 ID：`lazer.bilibili`
- 版本：`0.1.0`
- API 版本：`1`
- 平台 ID：`bilibili`
- 登录方式：扫码 / Cookie 导入

## 安装

### 方式一：直接导入 ZIP

1. 打开 Lazer → 左侧菜单 → **插件市场**
2. 右上角选择 **从文件安装**（或直接进入插件管理页导入）
3. 选择 `dist/lazer.bilibili-0.1.0.zip`
4. 安装完成后，在音源切换里选 **哔哩哔哩**

### 方式二：自己打包

```bash
node tools/build.js
# 产物: dist/lazer.bilibili-0.1.0.zip
# 同时打印 sha256 与市场索引条目
```

打包脚本是零依赖的纯 Node 实现（自己写 ZIP 结构），固定时间戳，同样的源码永远产出同样的字节，方便校验。

## 登录

不登录也能用：搜索、播放、UP 主、分区、推荐全都可用。

登录后额外解锁 **收藏夹**（收藏 / 取消收藏、收藏夹列表）。

### 扫码登录

插件市场里选择 **哔哩哔哩 → 扫码登录**，用哔哩哔哩手机 App 扫码确认即可。会话 Cookie 落在插件的 `host.storage_*` 里，不进连接偏好。

### Cookie 登录

浏览器登录 [bilibili.com](https://www.bilibili.com)，F12 → Application → Cookies，复制整段，至少包含：

```
SESSDATA=...
bili_jct=...
DedeUserID=...
```

粘贴进 Cookie 输入框。`bili_jct` 是写操作（收藏、点赞）的 CSRF 令牌，缺了就只能读。

## 能力对照

| 宿主操作 | 插件实现 | 说明 |
| --- | --- | --- |
| `search` | `/x/web-interface/wbi/search/type` | 视频搜索 + UP 主搜索（仅在首页带 UP 主） |
| `song` | `/x/web-interface/view` | 视频详情转歌曲模型 |
| `stream` | `/x/player/wbi/playurl` | 取 `dash.audio` 音轨，按 quality 选档 |
| `lyrics` | `/x/player/wbi/v2` → 字幕 JSON | 字幕转 LRC；无字幕返回空数组 |
| `artist` | `/x/web-interface/card` | UP 主资料，不用 wbi 签名 |
| `artistSongs` | 搜索接口按 UP 名回查 | space 接口对匿名请求风控严格，走搜索兜底 |
| `playlist` / `playlistSongs` | `newlist` / `fav/resource/list` | 分区歌单与收藏夹 |
| `comments` / `setCommentLiked` | `/x/v2/reply` / `/x/v2/action` | 评论读取与点赞 |
| `homeFeed` | rcmd + popular + newlist | 推荐流、热门、分区入口 |
| `charts` | `config.rankZones` | 分区列表，每项渲染成歌单 |
| `radio` / `recommendations` | rcmd / `archive/related` | 相关推荐 |
| `favorites` / `setFavorite` | `fav/folder` + `fav/resource/deal` | 需登录 |
| `qrKey` / `qrUrl` / `qrCheck` | passport 二维码接口 | 801 等待 / 802 已扫 / 803 成功 / 800 过期 |

## 结构

```
manifest.json        插件清单（网络权限、能力、登录方式）
main.lua             入口：operation 分发 + 收藏写操作
bb/
  config.lua         所有协议常量（域名、UA、WBI 混排表、分区表）
  util.lua           编码、哈希、时间、文本清洗
  wbi.lua            WBI 签名（nav 取 key → 混排 → w_rid）
  transport.lua      Cookie 罐、buvid、请求封装、错误映射
  models.lua         B 站各种结构 → 通用歌曲/歌手/歌单/评论模型
  account.lua        session / 扫码 / Cookie / logout
  catalog.lua        搜索、播放、字幕、UP 主、评论、歌单
  discover.lua       首页、分区、收藏夹、推荐、电台
tools/build.js       零依赖打包器
test/host_stub.lua   本地 host 桩（curl + openssl md5 + 手写 JSON）
test/run.lua         端到端测试，直接打真实 B 站接口
```

## 本地测试

测试不依赖 Flutter，只要 Lua 5.3：

```bash
sudo apt install lua5.3
mkdir -p /tmp/bbtest
lua5.3 test/run.lua          # 全部用例
lua5.3 test/run.lua search   # 只跑名字含 search 的
```

测试桩做了这些事：

- 用 `curl` 发真实 HTTP，响应头里的多个 `Set-Cookie` 按宿主约定用换行拼接
- `host.crypto` 的 md5 走 `md5sum`，base64 走 `base64`
- 手写 JSON 编解码（含 `\uXXXX` → UTF-8 的最小实现）
- `host.storage_*` 落到 `/tmp/bbtest/storage.json`，`host.resetStorage()` 清空

75 个断言覆盖：describe、搜索、单曲、音频流（含 Referer 头）、字幕、UP 主、评论、分区、首页、推荐、电台、未登录 session、扫码 key/url/轮询、歌单分页不重复、未知操作返回 nil，以及**纯字符串工具与 id 解析**（专门覆盖下面那节说的 VM 缺陷）。

### 用真实 VM 验证（强烈建议）

`lua5.3` 测不出宿主 VM 的问题，因为问题恰恰出在模式匹配层。用收录在 `tools/vm/` 的脚本可以直接在 Lazer 的 VM 里跑：

```bash
cd tools/vm
dart pub get
dart run run_plugin.dart ../../ search '{"query":"周杰伦","limit":5}'
dart run run_plugin.dart ../../ homeFeed '{}'
dart run run_plugin.dart ../../ describe '{}'
```

输出里 `MAP KEYS` / `LIST LEN` 就是宿主实际会拿到的形状。

## 运行时兼容性（重要）

Lazer 用的是自己 fork 的 `lua_dardo_plus`（Dart 实现的 Lua 5.3），它的**模式匹配层有缺陷**，和官方 Lua 行为不同：

| 写法 | 官方 Lua 5.3 | Lazer 的 VM | 本插件的对策 |
| --- | --- | --- | --- |
| `#someString` | 返回长度 | **抛异常** | 一律用 `util.slen()` |
| `s:gsub(pat, rep)` | 替换 | **原样返回，计数恒 0** | 用 `util.replace()` 手写 |
| `s:gmatch(pat)` | 迭代 | **抛 RangeError** | 用 `util.split()` |
| `s:find(pat)` | 模式查找 | 返回 nil | 只用 `find(s, sub, 1, true)` 纯字面量 |
| `s:match(pat)` | 捕获 | 简单 pattern 可用 | 避免用，靠 `util.*` 手写 |
| `string.sub/rep/format/byte` | 正常 | 正常 | 可以放心用 |
| `table.sort/concat/insert` | 正常 | 正常 | 可以放心用 |
| `math.floor` | 正常 | 正常 | 可以放心用 |

所以插件里**没有任何一处** `gsub`/`gmatch`/`#str`。`bb/util.lua` 提供了一整套纯字符串实现（`replace` / `split` / `trim` / `afterLast` / `digitsOnly` / `stripTags` …），这些在官方 Lua 和 Lazer VM 上结果完全一致。

改插件时请守住这条：**不要引入模式匹配，也不要对字符串用 `#`**。

验证方式（本机装了 Dart 就能跑）：

```bash
# 用真实的 Lazer Lua VM 跑插件
dart run bin/run_plugin.dart /path/to/bilibili-plugin search '{"query":"周杰伦","limit":5}'
```

## 收藏夹（重点）

B 站收藏夹这条路有两个坑，都踩过并修好了：

**坑一：接口单页上限 40，宿主要 100**

Lazer 拉歌单固定按 `limit: 100` 一页来要，而 `/x/v3/fav/resource/list` 的 `ps` 最大 **40**，传 100 直接 `-400 请求错误`——一首都拿不到。插件内部会把 100 条拆成 3 页（40 + 40 + 20）拼起来，凑满 100 再返回。

**坑二：宿主怎么判断"还有下一页"**

宿主的两道终止条件是：

```dart
if (!page.hasMore || page.items.length < 100) return;   // platform_catalog.dart
hasMore: list.length >= limit                            // lua_music_gateway.dart
```

也就是说**只要返回不足 100 条，宿主就认为到底了**。所以插件必须在还有数据时真的给满 100 条，不能为了省请求只给一部分——这两处是硬约束，改代码时别动 `listArgs`（列表类分页**不截断**），也别把收藏夹批量改小。

**坑三：风控**

收藏夹接口对请求密度很敏感。一次拉 100 条要连发 3 个请求，如果用户在多个收藏夹之间来回点，很容易触发 `-412 request was banned`（HTTP 412 / 业务码 -412），**IP 会被封十几分钟到几小时**。

插件已经把 412 映射成限流错误（`code=429`）而不是"登录失效"，宿主会保留重试机会并提示稍后再试。真被封时只能等，换 IP 或开飞行模式重连有时能立刻恢复。

**收藏夹里的失效视频**会被自动跳过（`attr != 0`），不会显示成空曲目。

## 已知限制

- **B 站没有"歌曲/专辑"概念**，插件把视频映射成歌曲。模型里的 `albumName` 填的是分区名（音乐现场、翻唱…），只是让列表能看出分类。
- **歌手是 UP 主**，不是视频标题里的原唱。想要原唱得靠标题匹配，那样误判比现在更多，所以没做。
- **`space` 系接口对匿名请求返回 412 / -352**，`artistSongs` 退化成"按 UP 名搜索 + 按 mid 过滤"。登录态下命中率更高。
- **`ranking/v2` 接口目前被风控挡住**（返回 -352，带 WBI 签名也一样），分区歌单改用 `newlist`。`newlist` 的 `pn` 参数被服务端忽略，所以插件一次拉 50 条再本地切片，带 5 分钟缓存。
- **多 P 视频只播第一 P**。要多 P 得改 `stream` 里的 `pages` 选择逻辑。
- **音质取决于账号**：未登录一般 64K/132K，登录后能给到 192K；Hi-Res 和杜比要大会员。`quality` 参数只是偏好，实际由 B 站定。
- **字幕不是每首歌都有**，且大部分是 UP 主自己传的。`lyrics` 拿不到时返回空数组，宿主会显示"无歌词"。

## 排错

插件日志在 **设置 → 插件 → 哔哩哔哩 → 日志**。常见错误码：

| 码 | 含义 | 处理 |
| --- | --- | --- |
| `-101` | 账号未登录 | 扫码或贴 Cookie |
| `-352` | 风控拦截 | 稍等重试；或登录后重试 |
| `-403` | 访问权限不足 | 该接口需要登录 |
| `-799` | 请求过于频繁 | 等几分钟 |
| `-404` | 资源不存在 | 视频已删除或分区 rid 无效 |
| `412` | 触发反爬 | 换网络或等冷却 |

音频流播放失败（返回 403）通常是 **缺 Referer**。插件的 `stream` 返回值里已经带：

```lua
headers = {
  ["Referer"] = "https://www.bilibili.com/",
  ["User-Agent"] = "<桌面 Chrome UA>",
}
```

宿主会把它挂到这一次的播放请求上，不进队列快照。

## 发布到插件市场

`node tools/build.js` 会打印一条现成的索引 JSON，把它塞进 `plugins.json` 的 `plugins` 数组，改掉 `download` 指向你的 HTTPS 地址即可。市场索引格式参考 [docs/lua-plugins.md](https://github.com/chuxuehaocai/Lazer/blob/nextgen/docs/lua-plugins.md) 的「市场源」一节。

## 许可

MIT。接口协议属于哔哩哔哩，插件只做客户端协议适配，不分发任何音视频内容。
